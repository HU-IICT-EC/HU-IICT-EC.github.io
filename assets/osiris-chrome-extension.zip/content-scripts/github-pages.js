"use strict";
// content-scripts/github-pages.ts
// Enables two-way messaging between the extension and https://hu-iict-ec.github.io/
// Listen for messages from the extension (background or popup)
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    // Relay to the page context
    window.postMessage({
        source: "osiris-extension",
        payload: message,
    }, "*");
});
// Listen for messages from the page context
window.addEventListener("message", (event) => {
    // Only accept messages from the same origin (for security)
    if (event.origin !== "https://hu-iict-ec.github.io")
        return;
    if (!event.data || event.data.source !== "osiris-web")
        return;
    // Relay to the extension background
    chrome.runtime.sendMessage(event.data.payload, (response) => {
        // Optionally, relay the response back to the page
        window.postMessage({
            source: "osiris-extension-response",
            payload: response,
        }, "*");
    });
});
// Example usage for the website (to be run in the page context):
// window.postMessage({
//   source: 'osiris-web',
//   payload: { type: 'TRIGGER_REPORT_DOWNLOAD', reportUrl: 'https://osiris.hu.nl/path/to/report.pdf' }
// }, '*');
// Listen for extension responses:
// window.addEventListener('message', (event) => {
//   if (event.data && event.data.source === 'osiris-extension-response') {
//     console.log('Extension response:', event.data.payload);
//   }
// });
