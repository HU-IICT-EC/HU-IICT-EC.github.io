"use strict";
// content-scripts/github-pages.ts
// Enables two-way messaging between the extension and https://hu-iict-ec.github.io/
// Listen for messages from the extension (background or popup)
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    console.log("GitHub Pages content script received message:", message);
    // Relay to the page context
    window.postMessage({
        source: "osiris-extension",
        payload: message,
    }, "*");
    // Send acknowledgment for download completed messages
    if (message && message.type === "DOWNLOAD_COMPLETED") {
        console.log("Relaying download completion to page:", message);
        sendResponse({ received: true });
    }
});
// Listen for messages from the page context
window.addEventListener("message", (event) => {
    // Only accept messages from the same origin (for security)
    if (event.origin !== "https://hu-iict-ec.github.io" &&
        event.origin !== "http://localhost:4000")
        return;
    if (!event.data || event.data.source !== "osiris-web")
        return;
    // Relay to the extension background
    chrome.runtime.sendMessage(event.data.payload, (response) => {
        // Optionally, relay the response back to the page
        window.postMessage({
            source: "osiris-extension",
            payload: response,
        }, "*");
    });
});
/**
 * Register this tab with the background script
 */
function registerGitHubPagesTab() {
    chrome.runtime.sendMessage({
        type: "REGISTER_TAB",
        tabType: "github-pages",
    }, (response) => {
        if (response?.success) {
            console.log("GitHub Pages tab registered successfully with ID:", response.tabId);
        }
        else {
            console.error("Failed to register GitHub Pages tab");
        }
    });
}
/**
 * Unregister this tab when the page unloads
 */
function unregisterGitHubPagesTab() {
    chrome.runtime.sendMessage({
        type: "UNREGISTER_TAB",
    });
}
// Register the tab when the content script loads
registerGitHubPagesTab();
// Unregister when the page unloads
window.addEventListener("beforeunload", unregisterGitHubPagesTab);
