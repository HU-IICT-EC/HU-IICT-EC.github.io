"use strict";
// Content script for Osiris Rapporten page
// Handles report download, open report, and advanced search logic
// Handle messages related to report execution and download monitoring
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    switch (message.type) {
        case "DOWNLOAD_COMPLETED":
            notifyPopupOfResult({
                success: true,
                content: `Rapport download voltooid${message.filename ? `: ${message.filename}` : `: ${message.downloadId}`}`,
            });
            break;
        default:
            sendResponse({ success: false, message: "Unknown message type" });
    }
});
// Check for pending reports to open when page loads
document.addEventListener("DOMContentLoaded", () => {
    const pendingReportJson = sessionStorage.getItem("pendingReportToOpen");
    if (pendingReportJson) {
        sessionStorage.removeItem("pendingReportToOpen");
        try {
            const reportConfig = JSON.parse(pendingReportJson);
            // Wait a bit for the page to fully load before opening the report
            setTimeout(() => {
                const result = openReportByConfig(reportConfig);
                console.log("Auto-opened pending report:", reportConfig.reportname, result);
            }, 2000);
        }
        catch (error) {
            console.error("Error parsing pending report config:", error);
        }
    }
});
// Also check on script load in case DOMContentLoaded already fired
const pendingReportJson = sessionStorage.getItem("pendingReportToOpen");
if (pendingReportJson) {
    sessionStorage.removeItem("pendingReportToOpen");
    try {
        const reportConfig = JSON.parse(pendingReportJson);
        // Wait a bit for the page to fully load before opening the report
        setTimeout(() => {
            const result = openReportByConfig(reportConfig);
            console.log("Auto-opened pending report:", reportConfig.reportname, result);
        }, 2000);
    }
    catch (error) {
        console.error("Error parsing pending report config:", error);
    }
}
function openReportByConfig(reportConfig) {
    function prepopulateReportForm(config) {
        try {
            setBestandsformaat(config.fileType);
            // Wait a bit longer to ensure the file format change is processed
            setTimeout(() => {
                openAdvancedSearch(config);
            }, 2000);
        }
        catch (error) {
            console.error("Error prepopulating form:", error);
        }
    }
    function setBestandsformaat(bestandsformaat) {
        console.log(`Attempting to set bestandsformaat to: ${bestandsformaat}`);
        const label = Array.from(document.querySelectorAll("label")).find((label) => label.textContent?.toLowerCase().includes("bestandsformaat"));
        if (label) {
            console.log("Found bestandsformaat label:", label.textContent);
            const selectId = label.getAttribute("for");
            let selectElement = null;
            if (selectId) {
                selectElement = document.getElementById(selectId);
                if (selectElement) {
                    const option = Array.from(selectElement.options).find((option) => option.text
                        .toLowerCase()
                        .includes(bestandsformaat.toLowerCase()) ||
                        option.value.toLowerCase().includes(bestandsformaat.toLowerCase()));
                    if (option) {
                        selectElement.focus();
                        Array.from(selectElement.options).forEach((opt) => (opt.selected = false));
                        option.selected = true;
                        selectElement.value = option.value;
                        option.click();
                        // Also trigger the AOF event
                        triggerAOFQueueEvent(selectElement);
                    }
                }
            }
        }
    }
    function openAdvancedSearch(config) {
        const uitgebreidZoekenButton = document.querySelector('div[id*="uitgebreid_zoeken_knop"] a');
        if (uitgebreidZoekenButton) {
            uitgebreidZoekenButton.click();
            setTimeout(() => {
                addFilters(config.filters);
            }, 1000);
        }
    }
    function addFilters(filters) {
        if (filters.length === 0) {
            setTimeout(() => {
                closeAdvancedSearchPopup();
            }, 1000);
            return;
        }
        // Process each tab filter
        filters.forEach((tabFilter, tabIndex) => {
            setTimeout(() => {
                // Find and click the appropriate tab
                const tab = Array.from(document.querySelectorAll('div[id*="groep_selectie_link"] a')).find((el) => el.textContent?.trim().toLowerCase() === tabFilter.tab.toLowerCase());
                if (tab) {
                    const clickEvents = [
                        new MouseEvent("mousedown", { bubbles: true }),
                        new MouseEvent("click", { bubbles: true }),
                        new MouseEvent("mouseup", { bubbles: true }),
                    ];
                    clickEvents.forEach((event) => {
                        tab.dispatchEvent(event);
                    });
                    // Apply fields for this tab
                    setTimeout(() => {
                        tabFilter.fields.forEach((field, fieldIndex) => {
                            setTimeout(() => {
                                findAndSetFieldFilter(field.name, field.value);
                            }, fieldIndex * 500); // Stagger field application
                        });
                        // Close popup after all tabs are processed
                        if (tabIndex === filters.length - 1) {
                            setTimeout(() => {
                                closeAdvancedSearchPopup();
                            }, tabFilter.fields.length * 500 + 1000);
                        }
                    }, 1000);
                }
            }, tabIndex * 2000); // Stagger tab switching
        });
    }
    function findAndSetFieldFilter(field_name, value) {
        const tabContent = document.querySelector('div[id*="filters_container"] table table tbody');
        const labels = Array.from(tabContent.querySelectorAll("label"));
        const label = labels.find((el) => {
            const text = el.textContent?.trim().toLowerCase() || "";
            return text === field_name.toLowerCase();
        });
        if (label) {
            const input = label
                .closest("tr")
                ?.querySelector("input");
            if (input) {
                input.focus();
                input.value = value;
                triggerAOFQueueEvent(input);
            }
        }
    }
    function closeAdvancedSearchPopup() {
        const sluitenButton = Array.from(document.querySelectorAll('a.xfp[role="button"] span.xfx')).find((button) => {
            return button.textContent?.toLowerCase().trim() === "sluiten";
        });
        if (sluitenButton) {
            sluitenButton.click();
            // After closing the popup, press the Uitvoeren button
            setTimeout(() => {
                pressUitvoerenButton();
            }, 1000);
        }
    }
    function pressUitvoerenButton() {
        // Look for the Uitvoeren button with multiple strategies
        const uitvoerenButton = document.querySelector('div[id*="uitvoeren_knop"] a');
        if (uitvoerenButton) {
            // Try multiple click methods to ensure it works
            try {
                uitvoerenButton.click();
                // Also send immediate feedback to popup
                notifyPopupOfResult({
                    success: true,
                    content: "Rapport uitvoering gestart, wachten op download...",
                });
            }
            catch (error) {
                console.error("Error clicking Uitvoeren button:", error);
                notifyPopupOfResult({
                    success: false,
                    content: "Fout bij het klikken op Uitvoeren knop",
                });
            }
        }
    }
    function triggerAOFQueueEvent(inputField) {
        // Trigger comprehensive events for better compatibility
        const events = [
            new Event("focus", { bubbles: true, cancelable: true }),
            new Event("input", { bubbles: true, cancelable: true }),
            new Event("change", { bubbles: true, cancelable: true }),
            new Event("blur", { bubbles: true, cancelable: true }),
        ];
        // For select elements, also trigger specific select events
        if (inputField.tagName.toLowerCase() === "select") {
            events.push(new Event("select", { bubbles: true, cancelable: true }));
        }
        // Dispatch all events
        events.forEach((event) => {
            try {
                inputField.dispatchEvent(event);
            }
            catch (error) {
                console.warn("Error dispatching event:", event.type, error);
            }
        });
        // Custom AOF event
        const aofQueueEvent = new CustomEvent("AOFQueueEvent", {
            detail: {
                fieldName: inputField.name,
                fieldValue: inputField.value,
                fieldType: inputField.tagName.toLowerCase(),
                timestamp: new Date().toISOString(),
            },
        });
        inputField.dispatchEvent(aofQueueEvent);
    }
    try {
        const reportLink = Array.from(document.querySelectorAll("tr.x17d a")).find((link) => {
            const text = link.textContent?.trim() || "";
            return (text.startsWith(reportConfig.reportname) ||
                text.includes(reportConfig.reportname));
        });
        if (reportLink) {
            reportLink.click();
            setTimeout(() => {
                prepopulateReportForm(reportConfig);
            }, 1000);
            return {
                success: true,
                content: `Rapport ${reportConfig.reportname} geopend, formulier ingevuld en uitvoering gestart`,
            };
        }
        return {
            success: false,
            content: `Rapport ${reportConfig.reportname} niet gevonden`,
        };
    }
    catch (error) {
        return { success: false, content: `Error opening report: ${error}` };
    }
}
// Global helper function to notify popup of results
function notifyPopupOfResult(result) {
    // Send message to background script which can relay to popup
    chrome.runtime.sendMessage({
        type: "REPORT_EXECUTION_UPDATE",
        result: result,
    });
}
/**
 * Register this tab with the background script
 */
function registerRapportenTab() {
    chrome.runtime.sendMessage({
        type: "REGISTER_TAB",
        tabType: "rapporten",
    }, (response) => {
        if (response?.success) {
            console.log("Rapporten tab registered successfully with ID:", response.tabId);
        }
        else {
            console.error("Failed to register rapporten tab");
        }
    });
}
// Register the tab when the content script loads
registerRapportenTab();
