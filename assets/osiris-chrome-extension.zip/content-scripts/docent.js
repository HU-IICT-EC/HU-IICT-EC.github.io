"use strict";
// Content script for Osiris Docent page
// Handles checking and clicking the Rapporten menu
/**
 * Check if the Rapporten menu item is available on the current page
 */
function checkRapportenMenu() {
    try {
        const rapportenMenuItem = Array.from(document.querySelectorAll("td.af_commandMenuItem_menu-item-text")).some((el) => el.textContent?.trim() === "Rapporten");
        return { hasRapportenMenu: rapportenMenuItem };
    }
    catch (error) {
        console.error("Error checking Rapporten menu:", error);
        return { hasRapportenMenu: false };
    }
}
/**
 * Navigate to reports and open a specific report in the same tab
 */
function navigateAndOpenReport(reportConfig) {
    try {
        const rapportenMenuItem = Array.from(document.querySelectorAll("td.af_commandMenuItem_menu-item-text")).find((el) => el.textContent?.trim() === "Rapporten");
        if (rapportenMenuItem) {
            const clickableParent = rapportenMenuItem.closest("[role='menuitem']");
            if (clickableParent) {
                // Store the report config to open after navigation
                sessionStorage.setItem("pendingReportToOpen", JSON.stringify(reportConfig));
                // Set a timestamp for automatic cleanup
                sessionStorage.setItem("pendingReportTimestamp", Date.now().toString());
                // Click the Rapporten menu item to navigate to reports page
                clickableParent.click();
                return {
                    success: true,
                    content: `Navigating to reports and will open ${reportConfig.reportname}...`,
                };
            }
        }
        return { success: false, content: "Rapporten menu item not found" };
    }
    catch (error) {
        return { success: false, content: `Navigation error: ${error}` };
    }
}
/**
 * Clear any pending report state from session storage
 */
function clearReportState() {
    try {
        sessionStorage.removeItem("pendingReportToOpen");
        sessionStorage.removeItem("pendingReportTimestamp");
        console.log("Cleared pending report from session storage");
        return { success: true };
    }
    catch (error) {
        console.error("Error clearing report state:", error);
        return { success: false };
    }
}
/**
 * Check and clean up expired pending reports (older than 5 minutes)
 */
function cleanupExpiredReports() {
    try {
        const timestampStr = sessionStorage.getItem("pendingReportTimestamp");
        if (timestampStr) {
            const timestamp = parseInt(timestampStr, 10);
            const fiveMinutesAgo = Date.now() - 5 * 60 * 1000; // 5 minutes in milliseconds
            if (timestamp < fiveMinutesAgo) {
                console.log("Cleaning up expired pending report from session storage");
                clearReportState();
            }
        }
    }
    catch (error) {
        console.error("Error checking for expired reports:", error);
    }
}
const handleDocentMessage = (message, sender, sendResponse) => {
    switch (message.type) {
        case "CHECK_RAPPORTEN_MENU":
            const menuResult = checkRapportenMenu();
            sendResponse(menuResult);
            return false;
        case "NAVIGATE_AND_OPEN_REPORT":
            const openResult = navigateAndOpenReport(message.reportConfig);
            sendResponse(openResult);
            return false;
        case "CLEAR_REPORT_STATE":
            const clearResult = clearReportState();
            sendResponse(clearResult);
            return false;
        default:
            sendResponse({ success: false, message: "Unknown message type" });
            return false;
    }
};
chrome.runtime.onMessage.addListener(handleDocentMessage);
/**
 * Register this tab with the background script
 */
function registerDocentTab() {
    chrome.runtime.sendMessage({
        type: "REGISTER_TAB",
        tabType: "docent",
    }, (response) => {
        if (response?.success) {
            console.log("Docent tab registered successfully with ID:", response.tabId);
        }
        else {
            console.error("Failed to register docent tab");
        }
    });
}
/**
 * Unregister this tab when the page unloads
 */
function unregisterDocentTab() {
    chrome.runtime.sendMessage({
        type: "UNREGISTER_TAB",
    });
}
// Register the tab when the content script loads
registerDocentTab();
// Unregister when the page unloads
window.addEventListener("beforeunload", unregisterDocentTab);
// Clean up expired reports on interval
setInterval(cleanupExpiredReports, 60 * 1000); // Check every minute
// Clean up expired reports when the page loads
cleanupExpiredReports();
