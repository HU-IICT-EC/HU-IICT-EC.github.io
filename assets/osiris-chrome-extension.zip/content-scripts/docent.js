"use strict";
// Content script for Osiris Docent page
// Handles checking and clicking the Rapporten menu
/**
 * Check if the Rapporten menu item is available on the current page
 */
function checkRapportenMenu() {
    try {
        const rapportenMenuItem = Array.from(document.querySelectorAll("td.af_commandMenuItem_menu-item-text")).some((el) => el.textContent?.trim() === "Rapporten");
        return { hasRapportenMenu: rapportenMenuItem };
    }
    catch (error) {
        console.error("Error checking Rapporten menu:", error);
        return { hasRapportenMenu: false };
    }
}
/**
 * Navigate to reports and open a specific report in the same tab
 */
function navigateAndOpenReport(reportConfig) {
    try {
        const rapportenMenuItem = Array.from(document.querySelectorAll("td.af_commandMenuItem_menu-item-text")).find((el) => el.textContent?.trim() === "Rapporten");
        if (rapportenMenuItem) {
            const clickableParent = rapportenMenuItem.closest("[role='menuitem']");
            if (clickableParent) {
                // Store the report config to open after navigation
                sessionStorage.setItem("pendingReportToOpen", JSON.stringify(reportConfig));
                // Click the Rapporten menu item to navigate to reports page
                clickableParent.click();
                return {
                    success: true,
                    content: `Navigating to reports and will open ${reportConfig.reportname}...`,
                };
            }
        }
        return { success: false, content: "Rapporten menu item not found" };
    }
    catch (error) {
        return { success: false, content: `Navigation error: ${error}` };
    }
}
const handleDocentMessage = (message, sender, sendResponse) => {
    switch (message.type) {
        case "CHECK_RAPPORTEN_MENU":
            const menuResult = checkRapportenMenu();
            sendResponse(menuResult);
            return false;
        case "NAVIGATE_AND_OPEN_REPORT":
            const openResult = navigateAndOpenReport(message.reportConfig);
            sendResponse(openResult);
            return false;
        default:
            sendResponse({ success: false, message: "Unknown message type" });
            return false;
    }
};
chrome.runtime.onMessage.addListener(handleDocentMessage);
/**
 * Register this tab with the background script
 */
function registerDocentTab() {
    chrome.runtime.sendMessage({
        type: "REGISTER_TAB",
        tabType: "docent",
    }, (response) => {
        if (response?.success) {
            console.log("Docent tab registered successfully with ID:", response.tabId);
        }
        else {
            console.error("Failed to register docent tab");
        }
    });
}
/**
 * Unregister this tab when the page unloads
 */
function unregisterDocentTab() {
    chrome.runtime.sendMessage({
        type: "UNREGISTER_TAB",
    });
}
// Register the tab when the content script loads
registerDocentTab();
// Unregister when the page unloads
window.addEventListener("beforeunload", unregisterDocentTab);
