"use strict";
// Background script for Osiris Chrome Extension
// Service worker that handles download requests
const registeredTabs = new Map();
/**
 * Handles navigating to reports and opening a specific report
 */
const handleNavigateAndOpenReport = (message, sender, sendResponse) => {
    // Use the existing function to find the Osiris tab
    findOsirisTab().then((osirisTab) => {
        if (!osirisTab || !osirisTab.id) {
            sendResponse({ success: false, content: "No Osiris tab found" });
            return;
        }
        // Send message to the Osiris tab to navigate and open the report
        chrome.tabs.sendMessage(osirisTab.id, message, (response) => {
            if (chrome.runtime.lastError) {
                sendResponse({
                    success: false,
                    content: chrome.runtime.lastError.message || "Unknown error",
                });
            }
            else {
                sendResponse(response);
            }
        });
    });
    return true;
};
/**
 * Handles checking for Rapporten menu availability
 */
const handleCheckRapportenMenu = (sender, sendResponse) => {
    findOsirisTab().then((osirisTab) => {
        if (!osirisTab || !osirisTab.id) {
            sendResponse({ hasRapportenMenu: false });
            return;
        }
        // Send message to the Osiris tab to navigate and open the report
        chrome.tabs.sendMessage(osirisTab.id, { type: "CHECK_RAPPORTEN_MENU" }, (response) => {
            if (chrome.runtime.lastError) {
                sendResponse({ hasRapportenMenu: false });
            }
            else {
                sendResponse(response || { hasRapportenMenu: false });
            }
        });
    });
    return true;
};
/**
 * Handles report execution result messages and relays them to all connected popups
 */
const handleReportExecutionUpdate = (message, sender, sendResponse) => {
    console.log("Report execution result received:", message.result);
    chrome.runtime
        .sendMessage({
        type: "REPORT_EXECUTION_UPDATE",
        result: message.result,
    })
        .catch(() => {
        console.log("No popup listeners for execution result");
    });
    sendResponse({ success: true });
    return false;
};
/**
 * Handles tab registration
 */
const handleRegisterTab = (message, sender, sendResponse) => {
    const tabId = sender.tab?.id;
    if (!tabId) {
        sendResponse({ success: false });
        return false;
    }
    const registeredTab = {
        tabId,
        type: message.tabType,
        url: sender.tab?.url,
        timestamp: Date.now(),
    };
    registeredTabs.set(tabId, registeredTab);
    console.log(`Registered ${message.tabType} tab with ID: ${tabId}`);
    sendResponse({ success: true, tabId });
    return false;
};
/**
 * Handles tab unregistration
 */
const handleUnregisterTab = (sender, sendResponse) => {
    const tabId = sender.tab?.id;
    if (!tabId) {
        sendResponse({ success: false });
        return false;
    }
    const wasRegistered = registeredTabs.delete(tabId);
    console.log(`Unregistered tab with ID: ${tabId}, was registered: ${wasRegistered}`);
    sendResponse({ success: true });
    return false;
};
/**
 * Handles version requests
 */
const handleVersion = (sendResponse) => {
    const manifest = chrome.runtime.getManifest();
    sendResponse({ version: manifest.version });
    return false;
};
/**
 * Handles messages from popup and content scripts
 * Routes download requests and webpage interaction requests
 */
const handleMessage = (message, sender, sendResponse) => {
    switch (message.type) {
        case "NAVIGATE_AND_OPEN_REPORT":
            return handleNavigateAndOpenReport(message, sender, sendResponse);
        case "CHECK_RAPPORTEN_MENU":
            return handleCheckRapportenMenu(sender, sendResponse);
        case "REPORT_EXECUTION_UPDATE":
            return handleReportExecutionUpdate(message, sender, sendResponse);
        case "REGISTER_TAB":
            return handleRegisterTab(message, sender, sendResponse);
        case "UNREGISTER_TAB":
            return handleUnregisterTab(sender, sendResponse);
        case "VERSION":
            return handleVersion(sendResponse);
        default:
            sendResponse({ success: false, error: "Unknown message type" });
            return false;
    }
};
chrome.runtime.onMessage.addListener(handleMessage);
/**
 * Clean up registered tabs when they are closed
 */
chrome.tabs.onRemoved.addListener((tabId) => {
    const wasRegistered = registeredTabs.delete(tabId);
    if (wasRegistered) {
        console.log(`Cleaned up closed tab with ID: ${tabId}`);
    }
});
/**
 * Utility function to get registered tabs by type
 */
function getRegisteredTabsByType(type) {
    return Array.from(registeredTabs.values()).filter((tab) => tab.type === type);
}
/**
 * Utility function to send message to specific registered tab
 */
function sendMessageToRegisteredTab(tabId, message) {
    return new Promise((resolve, reject) => {
        if (!registeredTabs.has(tabId)) {
            reject(new Error(`Tab ${tabId} is not registered`));
            return;
        }
        chrome.tabs.sendMessage(tabId, message, (response) => {
            if (chrome.runtime.lastError) {
                reject(new Error(chrome.runtime.lastError.message));
            }
            else {
                resolve(response);
            }
        });
    });
}
/**
 * Utility function to send message to all registered tabs of a specific type
 */
function sendMessageToAllTabsOfType(type, message) {
    const tabsOfType = getRegisteredTabsByType(type);
    const promises = tabsOfType.map((tab) => sendMessageToRegisteredTab(tab.tabId, message));
    return Promise.allSettled(promises);
}
/**
 * Handle download completion events
 */
chrome.downloads.onChanged.addListener((downloadDelta) => {
    // Check if filename was just determined
    if (downloadDelta.filename?.current) {
        // Get the full download item to check if it's from Osiris
        chrome.downloads.search({ id: downloadDelta.id }, (results) => {
            if (results.length > 0) {
                const downloadItem = results[0];
                // Check if the download is from Osiris domain
                if (downloadItem.url && downloadItem.url.includes("osiris.hu.nl")) {
                    // Create the download completion message
                    const downloadCompletedMessage = {
                        type: "DOWNLOAD_COMPLETED",
                        filename: downloadDelta.filename.current,
                    };
                    // Send to all registered GitHub Pages tabs
                    sendMessageToAllTabsOfType("github-pages", downloadCompletedMessage)
                        .then((results) => {
                        console.log("Download completion messages sent to GitHub Pages tabs:", results.length);
                    })
                        .catch((error) => {
                        console.error("Error sending download completion messages:", error);
                    }); // Clear report state from docent tabs first
                    const docentTabs = getRegisteredTabsByType("docent");
                    if (docentTabs.length > 0) {
                        docentTabs.forEach(async (docentTab) => {
                            try {
                                await sendMessageToRegisteredTab(docentTab.tabId, {
                                    type: "CLEAR_REPORT_STATE",
                                });
                                console.log(`Cleared report state for docent tab ${docentTab.tabId}`);
                            }
                            catch (error) {
                                console.log(`Could not clear state for docent tab ${docentTab.tabId}:`, error);
                            }
                        });
                    }
                    // Close rapporten tab if it was opened
                    const rapportenTabs = getRegisteredTabsByType("rapporten");
                    if (rapportenTabs.length > 0) {
                        rapportenTabs.forEach((tab) => {
                            chrome.tabs.remove(tab.tabId, () => {
                                console.log(`Closed rapporten tab with ID: ${tab.tabId}`);
                            });
                        });
                    }
                }
            }
        });
    }
});
/**
 * Find an existing Osiris docent tab using the registry first, then fallback to query
 */
async function findOsirisTab() {
    // First try to find a registered docent tab
    const registeredDocentTabs = getRegisteredTabsByType("docent");
    if (registeredDocentTabs.length > 0) {
        // Verify the tab still exists and matches our criteria
        for (const registeredTab of registeredDocentTabs) {
            try {
                const tab = await chrome.tabs.get(registeredTab.tabId);
                if (tab.url &&
                    tab.url.includes("osiris.hu.nl/osiris_docent/faces/Start") &&
                    !tab.url.includes("login")) {
                    return tab;
                }
            }
            catch (error) {
                // Tab might have been closed, it will be cleaned up by the onRemoved listener
                console.log(`Registered tab ${registeredTab.tabId} no longer exists`);
            }
        }
    }
    // Fallback to the original query method
    return new Promise((resolve) => {
        chrome.tabs.query({}, async (tabs) => {
            const osirisTab = tabs.find((tab) => tab.url &&
                tab.url.includes("osiris.hu.nl/osiris_docent/faces/Start") &&
                !tab.url.includes("login"));
            if (!osirisTab || !osirisTab.id) {
                resolve(null);
                return;
            }
            resolve(osirisTab);
        });
    });
}
