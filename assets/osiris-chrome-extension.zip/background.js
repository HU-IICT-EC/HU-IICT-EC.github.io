"use strict";
// Background script for Osiris Chrome Extension
// Service worker that handles download requests
/**
 * Handles navigating to reports and opening a specific report
 */
const handleNavigateAndOpenReport = (message, sender, sendResponse) => {
    // Use the existing function to find the Osiris tab
    findOsirisTab().then((osirisTab) => {
        if (!osirisTab || !osirisTab.id) {
            sendResponse({ success: false, content: "No Osiris tab found" });
            return;
        }
        // Send message to the Osiris tab to navigate and open the report
        chrome.tabs.sendMessage(osirisTab.id, message, (response) => {
            if (chrome.runtime.lastError) {
                sendResponse({
                    success: false,
                    content: chrome.runtime.lastError.message || "Unknown error",
                });
            }
            else {
                sendResponse(response);
            }
        });
    });
    return true;
};
/**
 * Handles checking for Rapporten menu availability
 */
const handleCheckRapportenMenu = (sender, sendResponse) => {
    findOsirisTab().then((osirisTab) => {
        if (!osirisTab || !osirisTab.id) {
            sendResponse({ hasRapportenMenu: false });
            return;
        }
        // Send message to the Osiris tab to navigate and open the report
        chrome.tabs.sendMessage(osirisTab.id, { type: "CHECK_RAPPORTEN_MENU" }, (response) => {
            if (chrome.runtime.lastError) {
                sendResponse({ hasRapportenMenu: false });
            }
            else {
                sendResponse(response || { hasRapportenMenu: false });
            }
        });
    });
    return true;
};
/**
 * Handles report execution result messages and relays them to all connected popups
 */
const handleReportExecutionUpdate = (message, sender, sendResponse) => {
    console.log("Report execution result received:", message.result);
    // Relay the result to all extension views (popups, options pages, etc.)
    chrome.runtime
        .sendMessage({
        type: "REPORT_EXECUTION_UPDATE",
        result: message.result,
    })
        .catch(() => {
        // Ignore errors if no listeners (popup might be closed)
        console.log("No popup listeners for execution result");
    });
    sendResponse({ success: true });
    return false;
};
/**
 * Handles messages from popup and content scripts
 * Routes download requests and webpage interaction requests
 */
const handleMessage = (message, sender, sendResponse) => {
    switch (message.type) {
        case "NAVIGATE_AND_OPEN_REPORT":
            return handleNavigateAndOpenReport(message, sender, sendResponse);
        case "CHECK_RAPPORTEN_MENU":
            return handleCheckRapportenMenu(sender, sendResponse);
        case "REPORT_EXECUTION_UPDATE":
            return handleReportExecutionUpdate(message, sender, sendResponse);
        case "GET_CURRENT_TAB_ID":
            return handleGetCurrentTabId(sender, sendResponse);
        case "START_DOWNLOAD_MONITORING":
            return handleStartDownloadMonitoring(message, sender, sendResponse);
        case "STOP_DOWNLOAD_MONITORING":
            return handleStopDownloadMonitoring(message, sender, sendResponse);
        default:
            sendResponse({ success: false, error: "Unknown message type" });
            return false;
    }
};
chrome.runtime.onMessage.addListener(handleMessage);
// Download monitoring state
const downloadMonitoringTabs = new Set();
const downloadMonitoringTimeouts = new Map();
/**
 * Get the current tab ID for the sender
 */
const handleGetCurrentTabId = (sender, sendResponse) => {
    if (sender.tab?.id) {
        sendResponse({ tabId: sender.tab.id });
    }
    else {
        sendResponse({});
    }
    return false;
};
/**
 * Start monitoring downloads for a specific tab
 */
const handleStartDownloadMonitoring = (message, sender, sendResponse) => {
    const tabId = message.tabId;
    // Stop any existing monitoring for this tab
    if (downloadMonitoringTabs.has(tabId)) {
        const existingTimeout = downloadMonitoringTimeouts.get(tabId);
        if (existingTimeout) {
            clearTimeout(existingTimeout);
        }
    }
    // Add tab to monitoring set
    downloadMonitoringTabs.add(tabId);
    console.log(`Started download monitoring for tab ${tabId}`);
    // Set up timeout for monitoring (5 minutes)
    const timeout = setTimeout(() => {
        downloadMonitoringTabs.delete(tabId);
        downloadMonitoringTimeouts.delete(tabId);
        // Notify content script of timeout
        chrome.tabs
            .sendMessage(tabId, {
            type: "DOWNLOAD_TIMEOUT",
            message: "Download monitoring timeout - geen download gedetecteerd binnen 5 minuten",
        })
            .catch(() => {
            // Tab might be closed, ignore error
        });
        console.log(`Download monitoring timeout for tab ${tabId}`);
    }, 5 * 60 * 1000); // 5 minutes
    downloadMonitoringTimeouts.set(tabId, timeout);
    sendResponse({ success: true });
    return false;
};
/**
 * Stop monitoring downloads for a specific tab
 */
const handleStopDownloadMonitoring = (message, sender, sendResponse) => {
    const tabId = message.tabId;
    downloadMonitoringTabs.delete(tabId);
    const timeout = downloadMonitoringTimeouts.get(tabId);
    if (timeout) {
        clearTimeout(timeout);
        downloadMonitoringTimeouts.delete(tabId);
    }
    console.log(`Stopped download monitoring for tab ${tabId}`);
    sendResponse({ success: true });
    return false;
};
/**
 * Handle download completion events
 */
chrome.downloads.onCreated.addListener((downloadItem) => {
    // Check if any monitored tabs are associated with this download
    if (downloadMonitoringTabs.size > 0) {
        console.log("Download created:", downloadItem);
        // For each monitored tab, notify of download completion
        downloadMonitoringTabs.forEach((tabId) => {
            // Check if the download is likely from this tab (Osiris domain)
            if (downloadItem.url && downloadItem.url.includes("osiris.hu.nl")) {
                // Stop monitoring this tab
                downloadMonitoringTabs.delete(tabId);
                const timeout = downloadMonitoringTimeouts.get(tabId);
                if (timeout) {
                    clearTimeout(timeout);
                    downloadMonitoringTimeouts.delete(tabId);
                }
                // Notify the content script
                chrome.tabs
                    .sendMessage(tabId, {
                    type: "DOWNLOAD_COMPLETED",
                    downloadId: downloadItem.id,
                    filename: downloadItem.filename || downloadItem.url.split("/").pop(),
                })
                    .catch(() => {
                    // Tab might be closed, ignore error
                    console.log(`Could not notify tab ${tabId} of download completion`);
                });
                console.log(`Notified tab ${tabId} of download completion`);
            }
        });
    }
});
/**
 * Clean up monitoring when tabs are closed
 */
chrome.tabs.onRemoved.addListener((tabId) => {
    if (downloadMonitoringTabs.has(tabId)) {
        downloadMonitoringTabs.delete(tabId);
        const timeout = downloadMonitoringTimeouts.get(tabId);
        if (timeout) {
            clearTimeout(timeout);
            downloadMonitoringTimeouts.delete(tabId);
        }
        console.log(`Cleaned up download monitoring for closed tab ${tabId}`);
    }
});
/**
 * Find an existing Osiris docent tab with the "Rapporten" menu item
 */
async function findOsirisTab() {
    return new Promise((resolve) => {
        chrome.tabs.query({}, async (tabs) => {
            const osirisTab = tabs.find((tab) => tab.url &&
                tab.url.includes("osiris.hu.nl/osiris_docent/faces/Start") &&
                !tab.url.includes("login"));
            if (!osirisTab || !osirisTab.id) {
                resolve(null);
                return;
            }
            resolve(osirisTab);
        });
    });
}
