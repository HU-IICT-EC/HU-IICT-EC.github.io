"use strict";
// Popup script for Osiris Chrome Extension
// Provides UI and communicates with content scripts via background script
// Constants for this file only
const OSIRIS_URLS = {
    DOCENT_START_PAGE: "https://osiris.hu.nl/osiris_docent/faces/Start",
};
const EXTENSION_CONFIG = {
    POPUP_AUTO_CLOSE_DELAY: 2000,
};
/**
 * Update the UI based on Rapporten menu availability
 */
function updateUI(hasRapportenTab = false) {
    const statusElement = document.getElementById("status");
    const openOsirisButton = document.getElementById("open-osiris");
    if (!statusElement || !openOsirisButton) {
        return;
    }
    if (hasRapportenTab) {
        statusElement.innerHTML = "&#x2713; Osiris beschikbaar";
        statusElement.className = "status available";
        openOsirisButton.style.display = "none";
    }
    else {
        statusElement.textContent = "Open eerst Osiris";
        statusElement.className = "status unavailable";
        openOsirisButton.style.display = "block";
    }
}
document.addEventListener("DOMContentLoaded", async () => {
    const openOsirisButton = document.getElementById("open-osiris");
    const statusElement = document.getElementById("status");
    if (!openOsirisButton || !statusElement) {
        return;
    }
    // Listen for report execution updates
    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
        if (message.type === "REPORT_EXECUTION_UPDATE") {
            if (statusElement) {
                statusElement.textContent = message.result.content;
                statusElement.style.color = message.result.success ? "green" : "red";
            }
            sendResponse({ received: true });
        }
    });
    /**
     * Check if Rapporten tab is available
     */
    async function checkAvailability() {
        return new Promise((resolve) => {
            chrome.runtime.sendMessage({ type: "CHECK_RAPPORTEN_MENU" }, (response) => {
                const hasRapportenTab = response?.hasRapportenMenu || false;
                updateUI(hasRapportenTab);
                resolve({ hasRapportenTab });
            });
        });
    }
    // Check initial status
    await checkAvailability();
    // Periodically check availability to handle tab changes
    const intervalId = setInterval(async () => {
        await checkAvailability();
    }, 2000); // Check every 2 seconds
    // Clean up interval when popup closes
    window.addEventListener("beforeunload", () => {
        clearInterval(intervalId);
    });
    // Open Osiris button handler
    openOsirisButton.addEventListener("click", () => {
        statusElement.textContent = "Osiris Start pagina wordt geopend...";
        statusElement.style.color = "#333";
        chrome.tabs.create({
            url: OSIRIS_URLS.DOCENT_START_PAGE,
        }, (tab) => {
            if (chrome.runtime.lastError) {
                statusElement.textContent = "Kon Osiris niet openen";
                statusElement.style.color = "red";
            }
            else {
                statusElement.textContent = "Osiris Start pagina geopend";
                statusElement.style.color = "green";
                // Auto-close popup after opening
                setTimeout(() => {
                    window.close();
                }, EXTENSION_CONFIG.POPUP_AUTO_CLOSE_DELAY);
            }
        });
    });
});
