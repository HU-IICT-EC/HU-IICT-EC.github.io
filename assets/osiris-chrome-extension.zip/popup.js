"use strict";
// filepath: /home/lsangers/projects/osiris-chrome-extension/src/popup.ts
// Simplified popup script for Osiris Chrome Extension
// Provides UI and communicates with content scripts via background script
// Constants for this file only
const OSIRIS_URLS = {
    DOCENT_START_PAGE: "https://osiris.hu.nl/osiris_docent/faces/Start",
    REPORT_PAGE: "https://osiris.hu.nl/osiris_rapport/rapporten/faces/UIReportShell",
};
const EXTENSION_CONFIG = {
    POPUP_AUTO_CLOSE_DELAY: 2000,
};
/**
 * Find an existing Osiris docent tab with the "Rapporten" menu item
 */
async function findOsirisTabWithRapportenMenu() {
    return new Promise((resolve) => {
        chrome.tabs.query({}, async (tabs) => {
            // Look for existing Osiris docent tabs
            const osirisTab = tabs.find((tab) => tab.url &&
                tab.url.includes("osiris.hu.nl/osiris_docent/faces/Start") &&
                !tab.url.includes("login") // Avoid login pages
            );
            if (!osirisTab || !osirisTab.id) {
                resolve(null);
                return;
            }
            // Check if this tab has the "Rapporten" menu item using messaging
            try {
                chrome.tabs.sendMessage(osirisTab.id, { type: "CHECK_RAPPORTEN_MENU" }, (response) => {
                    if (chrome.runtime.lastError || !response?.hasRapportenMenu) {
                        resolve(null);
                    }
                    else {
                        resolve(osirisTab);
                    }
                });
            }
            catch (error) {
                console.error("Error checking Rapporten menu:", error);
                resolve(null);
            }
        });
    });
}
/**
 * Find an active Osiris reports tab
 */
async function findOsirisReportsTab() {
    return new Promise((resolve) => {
        chrome.tabs.query({}, async (tabs) => {
            // Look for existing Osiris reports tabs
            const reportsTab = tabs.find((tab) => tab.url &&
                tab.url.includes("osiris.hu.nl/osiris_rapport/rapporten/faces/UIReportShell"));
            if (!reportsTab || !reportsTab.id) {
                resolve(null);
                return;
            }
            resolve(reportsTab);
        });
    });
}
/**
 * Update the UI based on Rapporten menu availability and reports page status
 */
function updateUI(hasRapportenTab = false, hasReportsTab = false) {
    console.log("DEBUG: updateUI called with:", {
        hasRapportenTab,
        hasReportsTab,
    });
    const statusElement = document.getElementById("status");
    const openOsirisButton = document.getElementById("open-osiris");
    const reportSection = document.getElementById("report-section");
    const openReportButton = document.getElementById("open-report");
    if (!statusElement ||
        !openOsirisButton ||
        !reportSection ||
        !openReportButton) {
        console.error("Required UI elements not found");
        return;
    }
    console.log("DEBUG: All UI elements found successfully");
    if (hasReportsTab) {
        statusElement.innerHTML = "&#x2713; Op Rapporten pagina";
        statusElement.className = "status available";
        openOsirisButton.style.display = "none";
        reportSection.style.display = "block";
        openReportButton.disabled = false;
    }
    else if (hasRapportenTab) {
        statusElement.innerHTML = "&#x2713; Rapporten menu beschikbaar";
        statusElement.className = "status available";
        openOsirisButton.style.display = "none";
        reportSection.style.display = "block"; // Show report section directly
        openReportButton.disabled = false;
    }
    else {
        statusElement.textContent = "Open eerst de Osiris Start pagina";
        statusElement.className = "status unavailable";
        openOsirisButton.style.display = "block";
        reportSection.style.display = "none";
    }
}
/**
 * Update the UI elements with report configuration details
 */
function updateReportUI(reportConfig) {
    const reportTitle = document.getElementById("report-title");
    const openReportButton = document.getElementById("open-report");
    if (reportTitle) {
        reportTitle.textContent = `Rapport ${reportConfig.reportname} Openen`;
    }
    if (openReportButton) {
        openReportButton.textContent = `Open Rapport ${reportConfig.reportname}`;
    }
}
// Example report configuration - can be made configurable later
const reportConfig = {
    reportname: "9.1.06",
    fileType: "html",
    filters: [
        {
            tab: "docent",
            fields: [
                {
                    name: "rol",
                    value: "EXAMINATOR",
                },
                {
                    name: "docent",
                    value: "loek.sangers@hu.nl",
                },
            ],
        },
        {
            tab: "cursus",
            fields: [
                {
                    name: "collegejaar",
                    value: "2024",
                },
            ],
        },
    ],
};
document.addEventListener("DOMContentLoaded", async () => {
    const openOsirisButton = document.getElementById("open-osiris");
    const openReportButton = document.getElementById("open-report");
    const statusElement = document.getElementById("status");
    if (!openOsirisButton || !openReportButton || !statusElement) {
        return;
    }
    // Update UI with report configuration
    updateReportUI(reportConfig);
    // Listen for report execution updates
    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
        if (message.type === "REPORT_EXECUTION_UPDATE") {
            const result = message.result;
            if (statusElement) {
                statusElement.textContent = result.message;
                statusElement.style.color = result.success ? "green" : "red";
                if (result.success && result.downloadUrl) {
                    statusElement.textContent += ` (Download: ${result.downloadUrl})`;
                }
            }
            sendResponse({ received: true });
        }
    });
    /**
     * Check if Rapporten tab and Reports tab are available
     */
    async function checkAvailability() {
        const rapportenTab = await findOsirisTabWithRapportenMenu();
        const reportsTab = await findOsirisReportsTab();
        const hasRapportenTab = rapportenTab !== null;
        const hasReportsTab = reportsTab !== null;
        updateUI(hasRapportenTab, hasReportsTab);
        return { hasRapportenTab, hasReportsTab };
    }
    // Check initial status
    await checkAvailability();
    // Periodically check availability to handle tab changes
    const intervalId = setInterval(async () => {
        await checkAvailability();
    }, 2000); // Check every 2 seconds
    // Clean up interval when popup closes
    window.addEventListener("beforeunload", () => {
        clearInterval(intervalId);
    });
    // Open Osiris button handler
    openOsirisButton.addEventListener("click", () => {
        statusElement.textContent = "Osiris Start pagina wordt geopend...";
        statusElement.style.color = "#333";
        chrome.tabs.create({
            url: OSIRIS_URLS.DOCENT_START_PAGE,
        }, (tab) => {
            if (chrome.runtime.lastError) {
                statusElement.textContent = "Kon Osiris niet openen";
                statusElement.style.color = "red";
            }
            else {
                statusElement.textContent = "Osiris Start pagina geopend";
                statusElement.style.color = "green";
                // Auto-close popup after opening
                setTimeout(() => {
                    window.close();
                }, EXTENSION_CONFIG.POPUP_AUTO_CLOSE_DELAY);
            }
        });
    }); // Open specific report button handler
    openReportButton.addEventListener("click", async () => {
        // Check current state
        const { hasRapportenTab, hasReportsTab } = await checkAvailability();
        if (hasReportsTab) {
            // We're already on the reports page, open the report directly
            const reportsTab = await findOsirisReportsTab();
            if (!reportsTab || !reportsTab.id) {
                statusElement.textContent = "Geen actieve Rapporten pagina gevonden!";
                statusElement.style.color = "red";
                return;
            }
            statusElement.textContent = `Openen van rapport ${reportConfig.reportname}...`;
            statusElement.style.color = "#333";
            // Focus on the reports tab and send report opening message
            chrome.tabs.update(reportsTab.id, { active: true }, () => {
                if (chrome.runtime.lastError) {
                    statusElement.textContent =
                        "Kon niet naar Rapporten tabblad navigeren";
                    statusElement.style.color = "red";
                    return;
                }
                // Send report opening message to content script
                chrome.tabs.sendMessage(reportsTab.id, { type: "OPEN_REPORT", reportConfig: reportConfig }, (response) => {
                    if (chrome.runtime.lastError) {
                        statusElement.textContent = "Kon rapport niet openen";
                        statusElement.style.color = "red";
                    }
                    else if (response?.success) {
                        statusElement.textContent = response.message;
                        statusElement.style.color = "green";
                        // Auto-close popup after successful report opening
                        setTimeout(() => {
                            window.close();
                        }, EXTENSION_CONFIG.POPUP_AUTO_CLOSE_DELAY);
                    }
                    else {
                        statusElement.textContent =
                            response?.message ||
                                `Rapport ${reportConfig.reportname} niet gevonden`;
                        statusElement.style.color = "red";
                    }
                });
            });
        }
        else if (hasRapportenTab) {
            // We have access to the Rapporten menu, navigate and open the report
            const rapportenTab = await findOsirisTabWithRapportenMenu();
            if (!rapportenTab || !rapportenTab.id) {
                statusElement.textContent = "Geen actieve Osiris tabblad gevonden!";
                statusElement.style.color = "red";
                return;
            }
            statusElement.textContent = `Navigeren naar rapporten en openen van ${reportConfig.reportname}...`;
            statusElement.style.color = "#333";
            // Focus on the tab and send combined navigation and report opening message
            chrome.tabs.update(rapportenTab.id, { active: true }, () => {
                if (chrome.runtime.lastError) {
                    statusElement.textContent = "Kon niet naar Osiris tabblad navigeren";
                    statusElement.style.color = "red";
                    return;
                }
                // Send navigation and report opening message to content script
                chrome.tabs.sendMessage(rapportenTab.id, { type: "NAVIGATE_AND_OPEN_REPORT", reportConfig: reportConfig }, (response) => {
                    if (chrome.runtime.lastError) {
                        statusElement.textContent = "Kon niet naar rapporten navigeren";
                        statusElement.style.color = "red";
                    }
                    else if (response?.success) {
                        statusElement.textContent = response.message;
                        statusElement.style.color = "green";
                        // Auto-close popup after navigation starts
                        setTimeout(() => {
                            window.close();
                        }, EXTENSION_CONFIG.POPUP_AUTO_CLOSE_DELAY);
                    }
                    else {
                        statusElement.textContent =
                            response?.message || "Kon niet naar rapporten navigeren";
                        statusElement.style.color = "red";
                    }
                });
            });
        }
        else {
            statusElement.textContent = "Open eerst de Osiris Start pagina!";
            statusElement.style.color = "red";
        }
    });
});
